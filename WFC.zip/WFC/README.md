Part 1 improvements

Home webpage 
-Updates section made it one whole section which the video and text are all in 
-Updated insides my eleemts so i could style the logo created   <div class="logo"><h1> Women for Change<h1></div> that made ir easier for me to style in Css stylesheet

About webpage
-Updated <div class= "support-bar"> so users cn easly donate and be directed to the donate page 
-Updated insides my eleemts so i could style the logo created   <div class="logo"><h1> Women for Change<h1></div> that made ir easier for me to style in Css stylesheet

Glossay
-Update <details></details><summary></summary > elements and summary so i can create a disclosure widget widet in css so users can open and close
-Updated insides my eleemts so i could style the logo created   <div class="logo"><h1> Women for Change<h1></div> that made ir easier for me to style in Css stylesheet

Contact webpage 
-Linked a stylessheet from CHATGBT that alllows me create the logos for the social links that take the users to the different social platorms
-<ul class"social-links>  updated 
-Updated insides my eleemts so i could style the logo created   <div class="logo"><h1> Women for Change<h1></div> that made ir easier for me to style in Css stylesheet

Donate webpage
-Updated <span class="donate-btn"></span> for the users users so the can reach and see the differnt ways to donate and make it more appilying in the <section></sections>
-Updated insides my eleemts so i could style the logo created   <div class="logo"><h1> Women for Change<h1></div> that made ir easier for me to style in Css stylesheet

Part 2

-All stylesheets for Css created were external stylesheets

-For my differnt webpages i followed the same Headers and Navigations and base styles that made it easier for me to copy across the different webpages 

- Create media responses for the webpages so different screen sizes could interact with the webpages

-For contact webpage i got assistance on how to create the logos for the differnt social platorms so it coud it give me a hover 

- Donate i created blocks for the users to useid theyd like to donate , currently not fuctional but will be updated at a later stage(Part 3)

Footer sections i also copied the code across the differnt webpages to they all look the same

- In my GlossaryStyle.css created a dropdown style so my Definitions would open and close for the users and when the box is open it would open and turn purple. I got help from CHATGBT for my drop my dropdown area with the "➕" and "➖" which show the user when the box is open or close.